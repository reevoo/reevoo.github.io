var review = require('./app/review.js')

var r = review.all();
console.log(r);
