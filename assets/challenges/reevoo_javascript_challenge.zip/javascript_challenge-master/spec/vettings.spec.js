describe('vetting', function(){
  var r = require('./../app/review.js');
  var reviews;
  beforeEach(function(){
    reviews = r.all();
  });

  it('vets all reviews given', function(){
    pending('Please make this test pass');
    vetting.vet(reviews);
    reviews.forEach(function(review){
      expect(review.vetted()).toBe(true);
    });
  });

  it('sets the status on the correct reviews', function(){
    pending("Oh and this one too");
    vetting.vet(reviews);
    expect(review(1).accepted()).toBe(false);
    expect(review(1).rejection_reason).toEqual("Sorry you can't use bad language");

    expect(review(2).accepted()).toBe(true);

    expect(review(3).accepted()).toBe(false);
    expect(review(3).rejection_reason).toEqual("Sorry you can't have repetition");

    expect(review(4).accepted()).toBe(false);
    expect(review(4).rejection_reason).toEqual("Sorry you can't mention the price");

    expect(review(5).accepted()).toBe(true);

    expect(review(6).accepted()).toBe(false);
    expect(review(6).rejection_reason).toEqual("Sorry you can't use bad language");

    expect(review(7).accepted()).toBe(true);
  });

  function review(review_id){
    for (var i = 0; i < reviews.length; i++) {
      if (reviews[i].id == review_id)
        return reviews[0];
    }
  }
});
