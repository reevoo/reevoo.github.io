$:.unshift File.join(File.dirname(__FILE__), "..", "lib")
